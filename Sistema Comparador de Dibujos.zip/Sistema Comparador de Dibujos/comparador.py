import PySimpleGUI as sg
import cv2
import numpy as np
 
def main():
   sg.theme('SandyBeach')
   w, h = sg.Window.get_screen_size()
  
   contenedor1=[[sg.Image(filename='', key='-IMAGE1-')]]
   contenedor2=[[sg.Image(filename='', key='-IMAGE2-')]]
   contenedor4=[
       [sg.Button('Abrir imagen 1', size=(15,2), font='Consolas 11')],
       [sg.Button('Abrir imagen 2', size=(15,2), font='Consolas 11')],
       [sg.Button('Comparar',size=(15,2),font='Consolas 11')],
   ]
 
 
   layout = [
     [sg.Text('Imagenes', size=(60, 1), key='-nombre_archivo-',)],
     [sg.Column(contenedor1,size=(w/3, h-150), key='-colum1-'),
     sg.Column(contenedor2,size=(w/3, h-150), element_justification='center'),
     sg.Column(contenedor4,size=(w/6, h-150), element_justification='center'),
     ]
   ]
    #imagen1 e imagen2 representan las imágenes que solo usaremos para ver en la interfaz.
   
   imagen1 = np.ones((1000,500))#imagen para la interfaz.
   imagen2 = np.ones((1000,500))#imagen para la interfaz.
   
    # imagenp e imagenp2 representan nuestras imágenes con sus dimensiones originales.
    # Las cuales usaremos para las comparaciones
   
   imagenp = np.ones((100,100))# imagen con su dimensión original. 
   imagenp2 = np.ones((100,100))# imagen con su dimensión original.
 
   window = sg.Window('Comparador de dibujos', layout, location=(0,0))
 
   while True:
       event, values = window.read(timeout=50)
 
       if event == 'Salir' or event == sg.WIN_CLOSED:
           break
 
       if event == 'Abrir imagen 1':
           filename = sg.popup_get_file('Abrir archivo (PNG, JPG, JPEG)',file_types=(("Archivos JPG", "*.jpg"),("Archivos JPEG", "*.jpeg"),("Archivos PNG", "*.png"),), no_window=True) 
           if len(filename): 
               imagen1 = cv2.imread(filename) #Validar que el nombre de archivo no este en blanco ó vacío.
               imagenp = cv2.imread(filename)
               imagen1=cv2.resize(imagen1,[500,700])

               window['-colum1-'].contents_changed()
               window['-nombre_archivo-'].update("¡Imagen rescalada solo para su visualización y no para la comparación!")
               
               

       if event == 'Abrir imagen 2':
           filename = sg.popup_get_file('Abrir archivo (PNG, JPG, JPEG)',file_types=(("Archivos JPG", "*.jpg"),("Archivos JPEG", "*.jpeg"),("Archivos PNG", "*.png"),), no_window=True) 
           if len(filename):
               imagen2 = cv2.imread(filename) #Validar que el nombre de archivo no este en blanco
               imagenp2 = cv2.imread(filename)
               imagen2=cv2.resize(imagen2,[500,700])
               
               window['-nombre_archivo-'].update("¡Imagen rescalada solo para su visualización y no para la comparación!")
              

       if event == 'Comparar':
            try:
                w= int(imagenp.shape[1])
                h= int(imagenp.shape[0])
                dim=(w,h)
                imagenp2 = cv2.resize(imagenp2,dim,interpolation = cv2.INTER_AREA)

                shift = cv2.xfeatures2d.SIFT_create(nfeatures=10)

                kp_1, desc_1 = shift.detectAndCompute(imagenp, None)
                kp_2, desc_2 = shift.detectAndCompute(imagenp2, None)

                index_params = dict(algorithm=0, trees=5)
                search_params = dict()

                flann = cv2.FlannBasedMatcher(index_params, search_params)
                matches = flann.knnMatch(desc_1, desc_2, k=2)

                good_points = []
                for m, n in matches:
                    if m.distance < 0.6*n.distance:
                        good_points.append(m)

                number_keypoints = 0
                if (len(kp_1) <= len(kp_2)):
                    number_keypoints = len(kp_1)
                else:
                    number_keypoints = len(kp_2)


                result = cv2.drawMatches(imagenp, kp_1, imagenp2, kp_2, good_points, None)
                result = cv2.resize(result,(1900,1500))

                cv2.imshow("Resultado", cv2.resize(result, None, fx = 0.4, fy=0.4))
                cv2.imwrite("Resultado_de_comparar.jpg", result) 
                sg.popup('Resultado:','Puntos parecidos',len(good_points)-1)
                sg.popup('Resultado:','Porcentaje de parecidos',len(good_points) / number_keypoints * 100) 
            except:
                sg.popup('¡ADVERTENCIA!', 'no se han cargado las imagenes necesarias.','Asegurese tener ambas imagenes.')

       imgbytes1 = cv2.imencode('.png', imagen1)[1].tobytes()
       imgbytes2 = cv2.imencode('.png', imagen2)[1].tobytes()
      
       window['-IMAGE1-'].update(data=imgbytes1)
       window['-IMAGE2-'].update(data=imgbytes2)
main()
